require('dotenv').config();
const sql = require('mssql');

const config = {
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  server: process.env.DB_SERVER,
  database: process.env.DB_DATABASE,
  options: {
    encrypt: false, // สำหรับ Local development ให้เป็น false
    trustServerCertificate: true // ข้ามการตรวจ certificate
  }
};

const poolPromise = new sql.ConnectionPool(config)
  .connect()
  .then(pool => {
    console.log('✅ เชื่อมต่อ SQL Server สำเร็จ');
    return pool;
  })
  .catch(err => {
    console.error('❌ ไม่สามารถเชื่อมต่อ SQL Server:', err);
  });

module.exports = {
  sql,
  poolPromise
};