const express = require('express');
const cors = require('cors');
const { poolPromise } = require('./db');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// อนุญาต CORS ให้ Frontend (Vite)
app.use(cors({ origin: 'http://localhost:5173' }));
app.use(express.json());

// API สำหรับดึงข้อมูล Destination Analysis ทั้งหมด
app.get('/api/destinations', async (req, res) => {
  try {
    const pool = await poolPromise;
    const result = await pool.request().query('SELECT * FROM vw_DestinationAnalysis');
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// API สำหรับค้นหาตามชื่อจังหวัดหรือ DestinationName
app.get('/api/destinations/:name', async (req, res) => {
  try {
    const pool = await poolPromise;
    const { name } = req.params;
    const result = await pool.request()
      .input('searchName', req.params.name)
      .query('SELECT * FROM vw_DestinationAnalysis WHERE DestinationName = @searchName OR Province = @searchName');
    
    res.json(result.recordset);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.listen(PORT, () => {
  console.log(`🚀 Server รันอยู่ที่ http://localhost:${PORT}`);
});